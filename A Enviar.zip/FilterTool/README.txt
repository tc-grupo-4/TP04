Para correr el programa, simplemente hacer doble click en FilterTool.py
